from selenium import webdriver
from selenium.webdriver.common.by import By
import time
driver = webdriver.Chrome()
driver.get("https://abzmvcapp-chanad.azurewebsites.net/")
driver.maximize_window()
driver.find_element(By.XPATH,"/html/body/header/nav/div/div/ul[2]/li[2]/a").click()
email=driver.find_element(By.ID,"Input_Email").send_keys("konnegarishivani09@gmail.com")
password=driver.find_element(By.ID,"Input_Password").send_keys("Shiv@ni032002")
login_button=driver.find_element(By.ID,"login-submit").click()
time.sleep(3)
customer_query=driver.find_element(By.XPATH,"//a[normalize-space()='CustomerQuery']").click()
time.sleep(2)
dropdown=driver.find_element(By.ID,"dropdownMenuButton").click()
driver.find_element(By.XPATH,"//ul[@class='dropdown-menu show']//a[@class='dropdown-item'][normalize-space()='Details']").click()
back=driver.find_element(By.XPATH,"//a[@class='btn btn-outline-primary']").click()