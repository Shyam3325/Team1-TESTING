from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
import time
driver = webdriver.Chrome()
driver.get("https://abzmvcapp-chanad.azurewebsites.net/")
driver.maximize_window()
driver.find_element(By.XPATH,"/html/body/header/nav/div/div/ul[2]/li[2]/a").click()
email=driver.find_element(By.ID,"Input_Email").send_keys("konnegarishivani09@gmail.com")
password=driver.find_element(By.ID,"Input_Password").send_keys("Shiv@ni032002")
login_button=driver.find_element(By.ID,"login-submit").click()
time.sleep(3)
customer_query=driver.find_element(By.XPATH,"//a[normalize-space()='CustomerQuery']").click()
time.sleep(2)
create_new=driver.find_element(By.XPATH,"//a[@class='btn btn-primary']").click()
query_id=driver.find_element(By.ID,"QueryID").send_keys("")
cid=driver.find_element(By.ID,"CustomerID").send_keys("")
Description=driver.find_element(By.ID,"Description").send_keys("")
date_field = driver.find_element(By.XPATH, "//input[@id='QueryDate']")
date_field.clear()

desired_date = ""
date_field.send_keys(desired_date)

date_field.send_keys(Keys.RETURN)
status=driver.find_element(By.XPATH,"//select[@id='Status']").send_keys("")
time.sleep(3)
create=driver.find_element(By.XPATH,"//input[@value='Create']").click()
time.sleep(2)
qie_err=driver.find_element(By.XPATH,"//span[@id='QueryID-error']")
print("The QueryID field is required.")
description_err=driver.find_element(By.XPATH,"//input[@id='Description']")
print("The Description field is required.")
querydate_err=driver.find_element(By.XPATH,"//input[@id='QueryDate']")
print("The QueryDate field is required")
status_err=driver.find_element(By.XPATH,"//div[@class='col-md-4']//form")
print("The Status field is required.-"
      "")
