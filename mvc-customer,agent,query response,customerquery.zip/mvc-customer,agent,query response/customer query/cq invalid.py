from selenium import webdriver
from selenium.webdriver import Keys
from selenium.webdriver.common.by import By
import time
driver = webdriver.Chrome()
driver.get("https://abzmvcapp-chanad.azurewebsites.net/")
driver.maximize_window()
driver.find_element(By.XPATH,"/html/body/header/nav/div/div/ul[2]/li[2]/a").click()
email=driver.find_element(By.ID,"Input_Email").send_keys("konnegarishivani09@gmail.com")
password=driver.find_element(By.ID,"Input_Password").send_keys("Shiv@ni032002")
login_button=driver.find_element(By.ID,"login-submit").click()
time.sleep(3)
customer_query=driver.find_element(By.XPATH,"//a[normalize-space()='CustomerQuery']").click()
time.sleep(2)
create_new=driver.find_element(By.XPATH,"//a[@class='btn btn-primary']").click()
query_id=driver.find_element(By.ID,"QueryID").send_keys("Qu000012340012")
cid=driver.find_element(By.ID,"CustomerID").send_keys("C123456787")
Description=driver.find_element(By.ID,"Description").send_keys("I have a comprehensive policy for my 2023 Tesla Model 3. I am interested in adding a tire protection add-on and a personal accident cover. Could you provide me with details on how this will impact my premium?")
date_field = driver.find_element(By.XPATH, "//input[@id='QueryDate']")
date_field.clear()

desired_date = "05-Jan-2025 03:00 PM"
date_field.send_keys(desired_date)

date_field.send_keys(Keys.RETURN)
status=driver.find_element(By.XPATH,"//select[@id='Status']").send_keys("Active")
time.sleep(3)
create=driver.find_element(By.XPATH,"//input[@value='Create']").click()
time.sleep(2)
queryid_err=driver.find_element(By.XPATH,"//span[@id='QueryID-error']")
print("QueryID must be 10 Characters")