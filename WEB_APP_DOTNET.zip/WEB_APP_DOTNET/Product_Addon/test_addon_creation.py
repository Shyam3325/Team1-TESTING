import time

from WebDriverSetup import WebDriverSetup
from HomePage import HomePage
from LoginPage import LoginPage
from Product_AddonPage import AddonPage

def test_Addon_creation():
    # Setup WebDriver
    setup = WebDriverSetup()
    driver = setup.get_driver()
    driver.get("https://abzmvcapp-chanad.azurewebsites.net/")

    # Validate Home Page
    home_page = HomePage(driver)
    assert driver.title == "Home Page - ABZVehicleInsuranceMVCAPP", "Home page title mismatch!"

    # Login
    home_page.click_login()
    login_page = LoginPage(driver)
    login_page.login("shyam123pr@gmail.com", "Sam@pr12")

    # Navigate to Addon Page and Create New Addon
    addon_page =AddonPage (driver)
    addon_page.navigate_to_product()
    addon_page.Action_Drop_down()
    addon_page.click_on_addon()
    addon_page.click_create_new()
    time.sleep(2)
    addon_page.select_productID("PROD000002")


    #Fill details and submit
    product_data ={
        "AddonID":"ADDN000001",
        "AddonTitle" : "Driver Cover",
        "AddonDescription" : "Covers injuries to the driver caused during accidents"
    }

    addon_page.fill_product_details(product_data)
    addon_page.create_addon()
    print("Product ADD-ON Created successfully")

    # Close Driver
    setup.close_driver()

if __name__ == "__main__":
    test_Addon_creation()