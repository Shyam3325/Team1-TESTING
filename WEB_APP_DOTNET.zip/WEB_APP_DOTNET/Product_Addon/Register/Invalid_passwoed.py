from selenium import webdriver
from selenium.webdriver.common.by import By

#Open chrome and start the link
driver = webdriver.Chrome()
URL="http://abzvehiclemvcwebapp-akshitha.azurewebsites.net/"
driver.maximize_window()
driver.get(URL)
driver.implicitly_wait(10)

#Checking the title
actual_title = driver.title
expect_title = "Home Page - ABZVehicleInsuranceMvcProject"
driver.save_screenshot(".//actual_title.png")

if actual_title == expect_title:
    print("Home page open Successfully")
else:
    print("Unsuccessful")

#Click on register button
Reg_button=driver.find_element(By.XPATH,"//a[normalize-space()='Register']")
Reg_button.click()
driver.save_screenshot(".//Reg_button.png")

#Check title of the Register page

actual_title = driver.title
expect_title = "Register - ABZVehicleInsuranceMvcProject"

if actual_title == expect_title:
    print("Register page open Successfully")
else:
    print("Unsuccessful")

#Enter required fields in the text boxes
Enter_Email=driver.find_element(By.XPATH,"//input[@id='Input_Email']")
Enter_Email.send_keys("sam123pr@gmail.com")
Enter_Password=driver.find_element(By.XPATH,"//input[@id='Input_Password']")
Enter_Password.send_keys("sampr")
Enter_ConfirmPass=driver.find_element(By.XPATH,"//input[@id='Input_ConfirmPassword']")
Enter_ConfirmPass.click()
Alert = driver.find_element(By.XPATH,"//span[@id='Input_Password-error']").text
driver.save_screenshot(".//Alert.png")
print(Alert)