from selenium import webdriver
import time
from selenium.webdriver.common.by import By

#Open chrome and start the link
driver = webdriver.Chrome()
URL="https://abzmvcapp-chanad.azurewebsites.net/"
driver.maximize_window()
driver.implicitly_wait(10)
driver.get(URL)

#Checking the title
actual_title = driver.title
expect_title = "Home Page - ABZVehicleInsuranceMvcProject"
driver.save_screenshot(".//actual_title.png")

if actual_title == expect_title:
    print("Home page open Successfully")
else:
    print("Unsuccessful")

#Click on register button
Reg_button=driver.find_element(By.XPATH,"//a[normalize-space()='Register']")
Reg_button.click()
driver.save_screenshot(".//Reg_button.png")

#Check title of the Register page

actual_title = driver.title
expect_title = "Register - ABZVehicleInsuranceMvcProject"

if actual_title == expect_title:
    print("Register page open Successfully")
else:
    print("Unsuccessful")

#Enter required fields in the text boxes
Enter_Email=driver.find_element(By.XPATH,"//input[@id='Input_Email']")
Enter_Email.send_keys("shyam123pr@gmail.com")
Enter_Password=driver.find_element(By.XPATH,"//input[@id='Input_Password']")
Enter_Password.send_keys("Sam@pr12")
Enter_ConfirmPass=driver.find_element(By.XPATH,"//input[@id='Input_ConfirmPassword']")
Enter_ConfirmPass.send_keys("Sam@pr")
time.sleep(3)
driver.save_screenshot("./Enter_ConfirmPass.png")

#Click on registration
Register_btn=driver.find_element(By.XPATH,"//button[@id='registerSubmit']")
Register_btn.click()
time.sleep(3)
driver.save_screenshot(".//Register_btn.png")

ErrorMSG=driver.find_element(By.XPATH,"//span[@id='Input_ConfirmPassword-error']").text
print(ErrorMSG)
driver.save_screenshot(".//ErrorMSG.png")
