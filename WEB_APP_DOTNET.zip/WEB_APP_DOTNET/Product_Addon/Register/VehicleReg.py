from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

#Open chrome and start the link
driver = webdriver.Chrome()
URL="https://abzmvcapp-chanad.azurewebsites.net/"
driver.maximize_window()
driver.implicitly_wait(10)
driver.get(URL)

#Checking the title
actual_title = driver.title
expect_title = "Home Page - ABZVehicleInsuranceMVCAPP"
driver.save_screenshot(".//actual_title.png")

if actual_title == expect_title:
    print("Home page open Successfully")
else:
    print("Unsuccessful")

#Click on login button
driver.find_element(By.XPATH,"//a[normalize-space()='Login']").click()
email=driver.find_element(By.ID,"Input_Email")
email.send_keys("shyam123pr@gmail.com")
password=driver.find_element(By.ID,"Input_Password")
password.send_keys("Sam@pr12")
checkBox=driver.find_element(By.ID,"Input_RememberMe")#Optional
checkBox.click()
login_button=driver.find_element(By.ID,"login-submit")
login_button.click()
time.sleep(3)

#Navigate to vehicle page

Vehicle=driver.find_element(By.XPATH,"//a[normalize-space()='Vehicle']")
Vehicle.click()
#Click on create to create new vehicle registration
Create=driver.find_element(By.XPATH,"//a[normalize-space()='Create New']")
Create.click()

#Enter Details to Create a new vehicle Information
Reg_No=driver.find_element(By.ID,"RegNo")
Reg_No.send_keys("AP03BR9493")
Reg_Authority=driver.find_element(By.ID,"RegAuthority")
Reg_Authority.send_keys("Andhra pradesh")
Make=driver.find_element(By.ID,"Make")
Make.send_keys("Toyota")
Model=driver.find_element(By.ID,"Model")
Model.send_keys("Supra")
FuelType=driver.find_element(By.ID,"FuelType")
FuelType.send_keys("P")
Variant=driver.find_element(By.ID,"Variant")
Variant.send_keys("Hypersport")
EngineNo=driver.find_element(By.ID,"EngineNo")
EngineNo.send_keys("ENGSUP1234568789")
ChassisNO=driver.find_element(By.ID,"ChassisNo")
ChassisNO.send_keys("CHASUP123456789")
EngineCapacity=driver.find_element(By.ID,"EngineCapacity")
EngineCapacity.send_keys("1998")
SeatingCapacity=driver.find_element(By.ID,"SeatingCapacity")
SeatingCapacity.send_keys("2")
MfgYear=driver.find_element(By.ID,"MfgYear")
MfgYear.send_keys("2014")
RegDate=driver.find_element(By.ID,"RegDate")
RegDate.send_keys("20-Jan-2014")
BodyType=driver.find_element(By.ID,"BodyType")
BodyType.send_keys("Sedan")
LeasedBy=driver.find_element(By.ID,"LeasedBy")
LeasedBy.send_keys("Sam")
time.sleep(5)
OwnerID=driver.find_element(By.XPATH,"//select[@id='OwnerId']")
OwnerID.click()
time.sleep(3)
Customer=Select(OwnerID).select_by_visible_text("CUS0011234")
time.sleep(2)
Create=driver.find_element(By.XPATH,"//input[@value='Create']")
Create.click()
time.sleep(3)







