from selenium import webdriver
import time
from selenium.webdriver.common.by import By

#Open chrome and start the link
driver = webdriver.Chrome()
URL="http://abzvehiclemvcwebapp-akshitha.azurewebsites.net/"
driver.maximize_window()
driver.get(URL)
time.sleep(3)

#Checking the title
actual_title = driver.title
expect_title = "Home Page - ABZVehicleInsuranceMvcProject"
driver.save_screenshot(".//actual_title.png")

if actual_title == expect_title:
    print("Home page open Successfully")
else:
    print("Unsuccessful")

#Click on register button
Reg_button=driver.find_element(By.XPATH,"//a[normalize-space()='Register']")
Reg_button.click()
driver.save_screenshot(".//Reg_button.png")

#Check title of the Register page

actual_title = driver.title
expect_title = "Register - ABZVehicleInsuranceMvcProject"

if actual_title == expect_title:
    print("Register page open Successfully")
else:
    print("Unsuccessful")

#Enter required fields in the text boxes
Enter_Email=driver.find_element(By.XPATH,"//input[@id='Input_Email']")
Enter_Email.send_keys("shya")
time.sleep(3)
Enter_Password=driver.find_element(By.XPATH,"//input[@id='Input_Password']").click()
time.sleep(2)
warning = driver.find_element(By.XPATH,"//span[@id='Input_Email-error']").text
driver.save_screenshot(".//warning.png")
print(warning)



