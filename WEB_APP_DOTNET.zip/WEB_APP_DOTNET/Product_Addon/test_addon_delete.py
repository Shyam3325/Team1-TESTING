import time
from WebDriverSetup import WebDriverSetup
from HomePage import HomePage
from LoginPage import LoginPage
from Addon_Delete import AddonPage

def test_addon_delete():
    try:
        # Setup WebDriver
        setup = WebDriverSetup()
        driver = setup.get_driver()
        driver.get("https://abzmvcapp-chanad.azurewebsites.net/")

        # Validate Home Page
        home_page = HomePage(driver)
        print("Home page loaded successfully.")

        # Login
        home_page.click_login()
        login_page = LoginPage(driver)
        login_page.login("shyam123pr@gmail.com", "Sam@pr12")
        print("Login Successful.")

        delete_page =AddonPage(driver)
        delete_page.navigate_to_product()
        time.sleep(2)
        delete_page.Action_Drop_down()
        time.sleep(2)
        delete_page.click_on_addon()
        time.sleep(2)
        delete_page.Addon_dropdown()
        time.sleep(2)
        delete_page.click_on_delete()
        time.sleep(2)
        delete_page.Confirm_delete()
        time.sleep(2)
        print("Deleted addon details successfully")


    finally:
        # Close Browser
        driver.quit()

if __name__ == "__main__":
    test_addon_delete()