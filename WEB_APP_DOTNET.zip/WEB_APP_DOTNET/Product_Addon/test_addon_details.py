import time
from WebDriverSetup import WebDriverSetup
from HomePage import HomePage
from LoginPage import LoginPage
from Addon_Details import AddonPage

def test_addon_details():
    try:
        # Setup WebDriver
        setup = WebDriverSetup()
        driver = setup.get_driver()
        driver.get("https://abzmvcapp-chanad.azurewebsites.net/")

        # Validate Home Page
        home_page = HomePage(driver)
        print("Home page loaded successfully.")

        # Login
        home_page.click_login()
        login_page = LoginPage(driver)
        login_page.login("shyam123pr@gmail.com", "Sam@pr12")
        print("Login Successful.")

        details_page = AddonPage(driver)
        details_page.navigate_to_product()
        details_page.Action_Drop_down()
        details_page.click_on_addon()
        details_page.Addon_dropdown()
        time.sleep(2)
        details_page.click_on_details()
        time.sleep(2)
        details_page.click_on_BackList()
        time.sleep(2)

    finally:
        # Close Browser
        driver.quit()

if __name__ == "__main__":
    test_addon_details()