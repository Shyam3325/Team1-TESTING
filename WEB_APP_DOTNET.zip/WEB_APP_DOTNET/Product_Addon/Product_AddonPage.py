import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select
from BasePage import BasePage

class AddonPage(BasePage):
    PRODUCT_TAB = (By.XPATH, "//a[normalize-space()='Product']")
    Dropdown = (By.XPATH, "//tbody/tr[1]/td[7]/div[1]/button[1]")
    ADDON_BUTTON = (By.LINK_TEXT, "Add-on")
    CREATE_NEW_BUTTON = (By.XPATH, "//a[normalize-space()='Create New']")
    CREATE_BUTTON = (By.XPATH, "//input[@value='Create']")


    def __init__(self, driver):
        super().__init__(driver)

    def navigate_to_product(self):
        self.click(self.PRODUCT_TAB)

    def Action_Drop_down(self):
        self.driver.find_element(*self.Dropdown).click()

    def click_on_addon(self):
        element = self.driver.find_element(*self.ADDON_BUTTON)
        time.sleep(1)
        element.click()

    def click_create_new(self):
        self.click(self.CREATE_NEW_BUTTON)

    def select_productID    (self, ProductID):
        Product_dropdown = self.driver.find_element(By.NAME, "ProductID")
        Select(Product_dropdown).select_by_visible_text(ProductID)

    def fill_product_details(self, product_data):
        for field_id, value in product_data.items():
            locator = (By.ID, field_id)
            self.send_keys(locator, value)

    def create_addon(self):
        self.click(self.CREATE_BUTTON)