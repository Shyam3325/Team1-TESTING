import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

from BasePage import BasePage

class AddonPage(BasePage):
    PRODUCT_TAB = (By.XPATH, "//a[normalize-space()='Product']")
    Dropdown = (By.XPATH, "//tbody/tr[1]/td[7]/div[1]/button[1]")
    ADDON_BUTTON = (By.LINK_TEXT, "Add-on")
    Action_btn = (By.XPATH, "//tbody/tr[1]/td[5]/div[1]/button[1]")
    EDIT_TAB = (By.LINK_TEXT, "Edit")
    AddonID = (By.ID, "AddonID")
    AddonTitle = (By.ID, "AddonTitle")
    AddonDescription = (By.ID, "AddonDescription")
    SAVE_BUTTON = (By.XPATH, "//input[@value='Save']")


    def __init__(self, driver):
        super().__init__(driver)

    def navigate_to_product(self):
        self.click(self.PRODUCT_TAB)

    def Action_Drop_down(self):
        self.driver.find_element(*self.Dropdown).click()

    def click_on_addon(self):
        element = self.driver.find_element(*self.ADDON_BUTTON)
        time.sleep(1)
        element.click()

    def Addon_dropdown(self):
        self.driver.find_element(*self.Action_btn).click()

    def click_on_update(self):
        self.driver.find_element(*self.EDIT_TAB).click()

    def update_addon_details(self, data):
        """Update Addon details."""
        time.sleep(2)  # Wait for form to load
        self.driver.find_element(*self.AddonID).clear()
        self.driver.find_element(*self.AddonID).send_keys(data["AddonID"])
        self.driver.find_element(*self.AddonTitle).clear()
        self.driver.find_element(*self.AddonTitle).send_keys(data["AddonTitle"])
        self.driver.find_element(*self.AddonDescription).clear()
        self.driver.find_element(*self.AddonDescription).send_keys(data["AddonDescription"])

    def save_update(self):
        """Submit the Addon update form."""
        time.sleep(2)  # Wait for submit button to be ready
        self.driver.find_element(*self.SAVE_BUTTON).click()


