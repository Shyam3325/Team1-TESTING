from WebDriverSetup import WebDriverSetup
from HomePage import HomePage
from LoginPage import LoginPage
from Addon_update import AddonPage

def test_product_updation():
    try:
        # Setup WebDriver
        setup = WebDriverSetup()
        driver = setup.get_driver()
        driver.get("https://abzmvcapp-chanad.azurewebsites.net/")

        # Validate Home Page
        home_page = HomePage(driver)
        print("Home page loaded successfully.")

        # Login
        home_page.click_login()
        login_page = LoginPage(driver)
        login_page.login("shyam123pr@gmail.com", "Sam@pr12")
        print("Login Successful.")

        addon_page = AddonPage(driver)
        addon_page.navigate_to_product()
        addon_page.Action_Drop_down()
        addon_page.click_on_addon()
        addon_page.Addon_dropdown()
        addon_page.click_on_update()

        update_data = {
            "AddonID": "ADDN000002",
            "AddonTitle": "Breakdown coverage",
            "AddonDescription": "Provides Roadside assistance 24x7"

        }
        addon_page.update_addon_details(update_data)
        addon_page.save_update()
        print("Addon details updated.")

    finally:
        # Close Browser
        driver.quit()

if __name__ == "__main__":
    test_product_updation()