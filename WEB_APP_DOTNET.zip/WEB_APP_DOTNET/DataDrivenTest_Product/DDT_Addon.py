import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import XLutilities_Addon

#Open Chrome and Get URL
driver = webdriver.Chrome()
URL ="https://abzmvcapp-chanad.azurewebsites.net/"
driver.maximize_window()
driver.get(URL)

#Login in the website
Login =driver.find_element(By.XPATH,"//a[normalize-space()='Login']")
Login.click()
Email = driver.find_element(By.ID, "Input_Email")
Email.send_keys("shyam123pr@gmail.com")
Password = driver.find_element(By.ID, "Input_Password")
Password.send_keys("Sam@pr12")
driver.find_element(By.ID, "Input_RememberMe").click()
Login_btn = driver.find_element(By.ID, "login-submit")
Login_btn.click()

#Selecting Product page and creating new Products
Product_Tab = driver.find_element(By.LINK_TEXT, "Product")
Product_Tab.click()
Action_Tab = driver.find_element(By.XPATH, "//tbody/tr[1]/td[7]/div[1]/button[1]")
Action_Tab.click()
driver.find_element(By.LINK_TEXT, "Add-on").click()
path="C://DDT_Product/Product.xlsx"
rows=XLutilities_Addon.getRowCount(path,"Sheet2")

for r in range(2,rows+1):
    ProductID =XLutilities_Addon.readData(path,'Sheet2',r,1)
    AddonID = XLutilities_Addon.readData(path, 'Sheet2',r,2)
    AddonTitle = XLutilities_Addon.readData(path, 'Sheet2', r, 3)
    AddonDescription = XLutilities_Addon.readData(path, 'Sheet2', r, 4)


    #Click on create new product
    Create_new = driver.find_element(By.XPATH, "//a[normalize-space()='Create New']")
    Create_new.click()


    driver.find_element(By.NAME, "ProductID").send_keys(ProductID)
    driver.find_element(By.NAME, "AddonID").send_keys(AddonID)
    driver.find_element(By.NAME, "AddonTitle").send_keys(AddonTitle)
    driver.find_element(By.NAME, "AddonDescription").send_keys(AddonDescription)

    #Click on create button
    driver.find_element(By.XPATH, "//input[@value='Create']" ).click()

    time.sleep(2)


# Logout
Logout_btn=driver.find_element(By.XPATH, "//button[normalize-space()='Logout']")
Logout_btn.click()

# Close Browser
driver.quit()