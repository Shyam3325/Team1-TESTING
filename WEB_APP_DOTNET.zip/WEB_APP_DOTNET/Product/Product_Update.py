from selenium.webdriver.common.by import By
import time

class ProductPage:
    PRODUCT_TAB = (By.XPATH, "//a[normalize-space()='Product']")
    Dropdown = (By.XPATH, "//tbody/tr[1]/td[7]/div[1]/button[1]")
    EDIT_TAB = (By.LINK_TEXT, "Edit")
    ProductName = (By.ID,"ProductName")
    ProductDescription = (By.ID,"ProductDescription")
    ProductUIN = (By.ID, "ProductUIN")
    InsuredInterests = (By.ID, "InsuredInterests")
    PolicyCoverage = (By.ID, "PolicyCoverage")
    SAVE_BUTTON = (By.XPATH,"//input[@value='Save']")


    def __init__(self, driver):
        self.driver = driver

    def navigate_to_product(self):
        self.driver.find_element(*self.PRODUCT_TAB).click()

    def Action_Drop_down(self):
        self.driver.find_element(*self.Dropdown).click()

    def click_on_update(self):
        self.driver.find_element(*self.EDIT_TAB).click()

    def update_product_details(self, data):
        """Update Product details."""
        time.sleep(2)  # Wait for form to load
        self.driver.find_element(*self.ProductName).clear()
        self.driver.find_element(*self.ProductName).send_keys(data["ProductName"])
        self.driver.find_element(*self.ProductDescription).clear()
        self.driver.find_element(*self.ProductDescription).send_keys(data["ProductDescription"])
        self.driver.find_element(*self.ProductUIN).clear()
        self.driver.find_element(*self.ProductUIN).send_keys(data["ProductUIN"])
        self.driver.find_element(*self.InsuredInterests).clear()
        self.driver.find_element(*self.InsuredInterests).send_keys(data["InsuredInterests"])
        self.driver.find_element(*self.PolicyCoverage).clear()
        self.driver.find_element(*self.PolicyCoverage).send_keys(data["PolicyCoverage"])

    def save_update(self):
        """Submit the Product update form."""
        time.sleep(2)  # Wait for submit button to be ready
        self.driver.find_element(*self.SAVE_BUTTON).click()