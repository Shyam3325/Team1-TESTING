import time
from WebDriverSetup import WebDriverSetup
from HomePage import HomePage
from LoginPage import LoginPage
from Product_Search import ProductPage

def test_search_product():
    # Setup WebDriver
    setup = WebDriverSetup()
    driver = setup.get_driver()
    driver.get("https://abzmvcapp-chanad.azurewebsites.net/")

    # Validate Home Page
    home_page = HomePage(driver)
    assert driver.title == "Home Page - ABZVehicleInsuranceMVCAPP", "Home page title mismatch!"

    # Login
    home_page.click_login()
    login_page = LoginPage(driver)
    login_page.login("shyam123pr@gmail.com", "Sam@pr12")


    #Searching for a product
    SearchPage = ProductPage(driver)
    SearchPage.navigate_to_product()
    time.sleep(2)
    SearchPage.search_for_product("Comprehensive")
    time.sleep(2)
    SearchPage.click_on_search()
    time.sleep(2)

    setup.close_driver()

if __name__ == "__main__":
    test_search_product()

