import time
from WebDriverSetup import WebDriverSetup
from HomePage import HomePage
from LoginPage import LoginPage
from Product_Update import ProductPage

def test_product_updation():
    try:
        # Setup WebDriver
        setup = WebDriverSetup()
        driver = setup.get_driver()
        driver.get("https://abzmvcapp-chanad.azurewebsites.net/")

        # Validate Home Page
        home_page = HomePage(driver)
        assert driver.title == "Home Page - ABZVehicleInsuranceMVCAPP", "Home page title mismatch!"
        print("Home page loaded successfully.")

        # Login
        home_page.click_login()
        login_page = LoginPage(driver)
        login_page.login("shyam123pr@gmail.com", "Sam@pr12")

        # Navigate to Product Page and Update Product details
        product_page = ProductPage(driver)
        product_page.navigate_to_product()
        time.sleep(3)
        product_page.Action_Drop_down()
        product_page.click_on_update()


        update_data = {
        "ProductName" : "Comprehensive",
        "ProductDescription" : "ComprehensiveInsuranceWithAddOns",
        "ProductUIN" : "PRODUIN1234578123123",
        "InsuredInterests" : "PUBLIC CAR",
        "PolicyCoverage" : "5 years"
        }

        product_page.update_product_details(update_data)
        product_page.save_update()
        print("Product details updated")

    finally:
        # Close Browser
        driver.quit()

if __name__ == "__main__":
    test_product_updation()