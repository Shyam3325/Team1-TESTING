from selenium.webdriver.common.by import By
from BasePage import BasePage

class HomePage(BasePage):
    LOGIN_BUTTON = (By.XPATH, "//a[normalize-space()='Login']")

    def __init__(self, driver):
        super().__init__(driver)

    def click_login(self):
        self.click(self.LOGIN_BUTTON)