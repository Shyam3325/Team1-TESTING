import time
from selenium.webdriver.common.by import By
from BasePage import BasePage

class ProductPage(BasePage):
    PRODUCT_TAB = (By.XPATH, "//a[normalize-space()='Product']")
    SEARCH_BTN = (By.XPATH, "//input[@value='Search']")



    def __init__(self, driver):
        super().__init__(driver)

    def navigate_to_product(self):
        self.click(self.PRODUCT_TAB)

    def search_for_product(self, ProductName):
        Text_box =self.driver.find_element(By.ID, "searchValue")
        Text_box.send_keys(ProductName)

    def click_on_search(self):
        self.click(self.SEARCH_BTN)


