from WebDriverSetup import WebDriverSetup
from HomePage import HomePage
from LoginPage import LoginPage
from ProductPage import ProductPage

def test_product_creation():
    # Setup WebDriver
    setup = WebDriverSetup()
    driver = setup.get_driver()
    driver.get("https://abzmvcapp-chanad.azurewebsites.net/")

    # Validate Home Page
    home_page = HomePage(driver)
    assert driver.title == "Home Page - ABZVehicleInsuranceMVCAPP", "Home page title mismatch!"

    # Login
    home_page.click_login()
    login_page = LoginPage(driver)
    login_page.login("shyam123pr@gmail.com", "Sam@pr12")

    # Navigate to Product Page and Create New Vehicle
    product_page = ProductPage(driver)
    product_page.navigate_to_product()
    product_page.click_create_new()

    #Fill details and submit
    product_data ={
        "ProductID" : "PROD123456",
        "ProductName" : "ThirdpartyInsurance",
        "ProductDescription" : "ThirdPartyInsuranceWithAddons",
        "ProductUIN" : "PRODUIN1234578123413",
        "InsuredInterests" : "PRIVATE CAR",
        "PolicyCoverage" : "5 Years"
    }

    product_page.fill_product_details(product_data)
    product_page.create_product()

    # Close Driver
    setup.close_driver()

if __name__ == "__main__":
    test_product_creation()

