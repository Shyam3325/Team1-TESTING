import time
from selenium.webdriver.common.by import By
from BasePage import BasePage

class ProductPage(BasePage):
    PRODUCT_TAB = (By.XPATH, "//a[normalize-space()='Product']")
    Dropdown = (By.XPATH, "//tbody/tr[1]/td[7]/div[1]/button[1]")
    DELETE_BUTTON = (By.LINK_TEXT, "Delete")
    CONFIRM_DELETE = (By.XPATH, "//input[@value='Delete']")


    def __init__(self, driver):
        super().__init__(driver)

    def navigate_to_product(self):
        self.click(self.PRODUCT_TAB)

    def Action_Drop_down(self):
        self.driver.find_element(*self.Dropdown).click()

    def click_on_delete(self):
        element = self.driver.find_element(*self.DELETE_BUTTON)
        time.sleep(2)
        element.click()

    def Confirm_delete(self):
        Confirm = self.driver.find_element(*self.CONFIRM_DELETE)
        time.sleep(1)
        Confirm.click()