from selenium.webdriver.common.by import By
from BasePage import BasePage

class LoginPage(BasePage):
    EMAIL_FIELD = (By.ID, "Input_Email")
    PASSWORD_FIELD = (By.ID, "Input_Password")
    REMEMBER_ME_CHECKBOX = (By.ID, "Input_RememberMe")
    LOGIN_BUTTON = (By.ID, "login-submit")

    def __init__(self, driver):
        super().__init__(driver)

    def login(self, email, password):
        self.send_keys(self.EMAIL_FIELD, email)
        self.send_keys(self.PASSWORD_FIELD, password)
        self.click(self.REMEMBER_ME_CHECKBOX)  # Optional
        self.click(self.LOGIN_BUTTON)