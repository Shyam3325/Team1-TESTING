import time
from selenium.webdriver.common.by import By
from BasePage import BasePage

class ProductPage(BasePage):
    PRODUCT_TAB = (By.XPATH, "//a[normalize-space()='Product']")
    Dropdown = (By.XPATH, "//tbody/tr[1]/td[7]/div[1]/button[1]")
    DETAILS_BUTTON = (By.LINK_TEXT, "Details")
    BACK_LIST = (By.XPATH, "//a[normalize-space()='Back to List']")


    def __init__(self, driver):
        super().__init__(driver)

    def navigate_to_product(self):
        self.click(self.PRODUCT_TAB)

    def Action_Drop_down(self):
        self.driver.find_element(*self.Dropdown).click()

    def click_on_details(self):
        """Scroll to and click the Details button."""
        # Scroll to the DETAILS_BUTTON
        element = self.driver.find_element(*self.DETAILS_BUTTON)
        time.sleep(1)  # Allow page to stabilize
        element.click()

    def click_on_BackList(self):
        self.driver.find_element(*self.BACK_LIST).click()