from selenium.webdriver.common.by import By
from BasePage import BasePage

class ProductPage(BasePage):
    PRODUCT_TAB = (By.XPATH, "//a[normalize-space()='Product']")
    CREATE_NEW_BUTTON = (By.XPATH, "//a[normalize-space()='Create New']")
    CREATE_BUTTON = (By.XPATH, "//input[@value='Create']")


    def __init__(self, driver):
        super().__init__(driver)

    def navigate_to_product(self):
        self.click(self.PRODUCT_TAB)

    def click_create_new(self):
        self.click(self.CREATE_NEW_BUTTON)

    def fill_product_details(self, product_data):
        for field_id, value in product_data.items():
            locator = (By.ID, field_id)
            self.send_keys(locator, value)

    def create_product(self):
        self.click(self.CREATE_BUTTON)
