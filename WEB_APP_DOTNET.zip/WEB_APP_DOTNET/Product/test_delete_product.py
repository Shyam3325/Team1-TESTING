import time
from WebDriverSetup import WebDriverSetup
from HomePage import HomePage
from LoginPage import LoginPage
from Product_Delete import ProductPage

def test_delete_product():
    # Setup WebDriver
    setup = WebDriverSetup()
    driver = setup.get_driver()
    driver.get("https://abzmvcapp-chanad.azurewebsites.net/")

    # Validate Home Page
    home_page = HomePage(driver)
    assert driver.title == "Home Page - ABZVehicleInsuranceMVCAPP", "Home page title mismatch!"

    # Login
    home_page.click_login()
    login_page = LoginPage(driver)
    login_page.login("shyam123pr@gmail.com", "Sam@pr12")

    # Navigate to product Page and delete product details
    product_page = ProductPage(driver)
    product_page.navigate_to_product()
    product_page.Action_Drop_down()
    time.sleep(3)
    product_page.click_on_delete()
    time.sleep(2)
    product_page.Confirm_delete()

    setup.close_driver()


if __name__ == "__main__":
    test_delete_product()