from WebDriverSetup import WebDriverSetup
import time
from HomePage import HomePage
from LoginPage import LoginPage
from WEB_APP_DOTNET.Vehicle.Vehicle_Update import VehiclePage



def test_update_vehicle():
    try:
        # Setup WebDriver
        setup = WebDriverSetup()
        driver = setup.get_driver()
        driver.get("https://abzmvcapp-chanad.azurewebsites.net/")

        # Validate Home Page
        home_page = HomePage(driver)
        assert driver.title == "Home Page - ABZVehicleInsuranceMVCAPP", "Home page title mismatch!"
        print("Home page loaded successfully.")

        # Login
        # Login
        home_page.click_login()
        login_page = LoginPage(driver)
        login_page.login("shyam123pr@gmail.com", "Sam@pr12")
        print("Logged in successfully.")

        # Navigate to Vehicle Page and Edit Vehicle Details
        vehicle_page = VehiclePage(driver)
        vehicle_page.navigate_to_vehicle()
        print("Navigated to Vehicle page.")
        vehicle_page.click_on_action()
        time.sleep(5)
        vehicle_page.click_on_edit()
        print("Editing vehicle details.")

        # Update Vehicle Details
        update_data = {
            "RegAuthority": "Andhra Pradesh",
            "Make": "ToyotaG",
            "Model": "Supra",
            "FuelType": "D",
            "LeasedBy": "Shyam"
        }
        vehicle_page.update_vehicle_details(update_data)
        vehicle_page.submit_update()
        print("Vehicle details updated.")
        time.sleep(3)

    finally:
        # Close Browser
        driver.quit()


if __name__ == "__main__":
    test_update_vehicle()


