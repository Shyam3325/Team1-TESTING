from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from BasePage import BasePage
import time


class VehiclePage(BasePage):
    VEHICLE_TAB = (By.XPATH, "//a[normalize-space()='Vehicle']")
    CREATE_NEW_BUTTON = (By.XPATH, "//a[normalize-space()='Create New']")
    CREATE_BUTTON = (By.XPATH, "//input[@value='Create']")

    def __init__(self, driver):
        super().__init__(driver)

    def navigate_to_vehicle(self):
        self.click(self.VEHICLE_TAB)

    def click_create_new(self):
        self.click(self.CREATE_NEW_BUTTON)

    def fill_vehicle_details(self, vehicle_data):
        for field_id, value in vehicle_data.items():
            locator = (By.ID, field_id)
            self.send_keys(locator, value)

    def select_owner(self, owner_id):
        owner_dropdown = self.driver.find_element(By.NAME, "OwnerId")
        Select(owner_dropdown).select_by_visible_text(owner_id)

    def click_on_create(self):
        element = self.driver.find_element(*self.CREATE_BUTTON)
        time.sleep(1)  # Allow page to stabilize
        element.click()
