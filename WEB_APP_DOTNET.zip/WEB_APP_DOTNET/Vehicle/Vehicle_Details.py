import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.common import action_chains


class VehiclePage:
    # Locators
    VEHICLE_MENU = (By.XPATH, "//a[normalize-space()='Vehicle']")
    ACTION_BAR = (By.XPATH, "//tbody/tr[1]/td[16]/div[1]/button[1]")
    DETAILS_BUTTON = (By.LINK_TEXT, "Details")
    BACK_LIST = (By.XPATH,"//a[normalize-space()='Back to List']")

    def __init__(self, driver):
        self.driver = driver

    def navigate_to_vehicle(self):
        """Navigate to the Vehicle page."""
        time.sleep(2)  # Wait for page elements to load
        self.driver.find_element(*self.VEHICLE_MENU).click()

    def click_on_action(self):
        action = ActionChains(self.driver)
        Dropdown=self.driver.find_element(*self.ACTION_BAR)
        action.move_to_element(Dropdown).click().perform()

    def click_on_details(self):
        """Scroll to and click the Details button."""
        # Scroll to the DETAILS_BUTTON
        element = self.driver.find_element(*self.DETAILS_BUTTON)
        time.sleep(1)  # Allow page to stabilize
        element.click()

    def click_on_BackList(self):
        self.driver.find_element(*self.BACK_LIST).click()




