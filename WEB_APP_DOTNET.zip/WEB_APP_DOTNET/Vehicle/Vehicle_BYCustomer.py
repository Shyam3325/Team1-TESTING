from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from BasePage import BasePage
import time


class VehiclePage(BasePage):
    VEHICLE_TAB = (By.XPATH, "//a[normalize-space()='Vehicle']")
    ACTION_BAR = (By.XPATH, "//tbody/tr[1]/td[16]/div[1]/button[1]")
    BYCUSTOMER_BUTTON = (By.LINK_TEXT,"ByCustomer")
    BACK_LIST = (By.XPATH,"//a[normalize-space()='Back to List']")



    def __init__(self, driver):
        super().__init__(driver)

    def navigate_to_vehicle(self):
        self.click(self.VEHICLE_TAB)

    def click_on_action(self):
        action = ActionChains(self.driver)
        Dropdown=self.driver.find_element(*self.ACTION_BAR)
        action.move_to_element(Dropdown).click().perform()

    def click_on_bycustomer(self):
        element = self.driver.find_element(*self.BYCUSTOMER_BUTTON)
        time.sleep(1)  # Allow page to stabilize
        element.click()

    def click_on_BackList(self):
        self.driver.find_element(*self.BACK_LIST).click()