import time

from WebDriverSetup import WebDriverSetup
from HomePage import HomePage
from LoginPage import LoginPage
from VehiclePage import VehiclePage

def test_vehicle_registration():
    # Setup WebDriver
    setup = WebDriverSetup()
    driver = setup.get_driver()
    driver.get("https://abzmvcapp-chanad.azurewebsites.net/")

    # Validate Home Page
    home_page = HomePage(driver)
    assert driver.title == "Home Page - ABZVehicleInsuranceMVCAPP", "Home page title mismatch!"

    # Login
    home_page.click_login()
    login_page = LoginPage(driver)
    login_page.login("shyam123pr@gmail.com", "Sam@pr12")

    # Navigate to Vehicle Page and Create New Vehicle
    vehicle_page = VehiclePage(driver)
    vehicle_page.navigate_to_vehicle()
    vehicle_page.click_create_new()

    # Fill Details and Submit
    vehicle_data = {
        "RegNo": "AP03BR9493",
        "RegAuthority": "Andhra",
        "Make": "Toyota",
        "Model": "Supra Mk14",
        "FuelType": "P",
        "Variant": "Hypersport",
        "EngineNo": "ENGSUP1234568789",
        "ChassisNo": "CHASUP123456789",
        "EngineCapacity": "1998",
        "SeatingCapacity": "2",
        "MfgYear": "2014",
        "RegDate": "20-Jan-2014",
        "BodyType": "Sedan",
        "LeasedBy": "Sam"
    }
    vehicle_page.fill_vehicle_details(vehicle_data)
    vehicle_page.select_owner("CUS0002155")
    vehicle_page.click_on_create()
    time.sleep(5)

    # Close Driver
    setup.close_driver()

if __name__ == "__main__":
    test_vehicle_registration()
