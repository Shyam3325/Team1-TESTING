from selenium import webdriver

class WebDriverSetup:
    def __init__(self):
        self.driver = webdriver.Chrome()
        self.driver.maximize_window()
        self.driver.implicitly_wait(10)

    def get_driver(self):
        return self.driver

    def close_driver(self):
        self.driver.quit()
