import time

from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By


class VehiclePage:
    # Locators
    VEHICLE_MENU = (By.XPATH, "//a[normalize-space()='Vehicle']")
    SCROLL_DOWN =(By.XPATH,"//td[normalize-space()='AP03BR9493']")
    ACTION_BAR = (By.ID, "dropdownMenuButton")
    EDIT_BUTTON = (By.LINK_TEXT, "Edit")
    REG_NO = (By.ID, "RegNo")
    REG_AUTHORITY = (By.ID, "RegAuthority")
    MAKE = (By.ID, "Make")
    MODEL = (By.ID, "Model")
    FUEL_TYPE = (By.ID, "FuelType")
    Leased_by = (By.ID, "LeasedBy")
    SUBMIT_BUTTON = (By.XPATH, "//input[@value='Save']")

    def __init__(self, driver):
        self.driver = driver

    def navigate_to_vehicle(self):
        """Navigate to the Vehicle page."""
        time.sleep(2)  # Wait for page elements to load
        self.driver.find_element(*self.VEHICLE_MENU).click()

    def click_on_action(self):
        action = ActionChains(self.driver)
        Scrolldown=self.driver.find_element(*self.SCROLL_DOWN)
        Dropdown=self.driver.find_element(*self.ACTION_BAR)
        action.move_to_element(Scrolldown).perform()
        action.move_to_element(Dropdown).click().perform()

    def click_on_edit(self):
        """Scroll to and click the Edit button for a specific vehicle."""
        edit_button = self.driver.find_element(*self.EDIT_BUTTON)
        edit_button.click()
    def update_vehicle_details(self, data):
        """Update vehicle details."""
        time.sleep(2)  # Wait for form to load
        self.driver.find_element(*self.REG_AUTHORITY).clear()
        self.driver.find_element(*self.REG_AUTHORITY).send_keys(data["RegAuthority"])
        self.driver.find_element(*self.MAKE).clear()
        self.driver.find_element(*self.MAKE).send_keys(data["Make"])
        self.driver.find_element(*self.MODEL).clear()
        self.driver.find_element(*self.MODEL).send_keys(data["Model"])
        self.driver.find_element(*self.FUEL_TYPE).clear()
        self.driver.find_element(*self.FUEL_TYPE).send_keys(data["FuelType"])
        self.driver.find_element(*self.Leased_by).clear()
        self.driver.find_element(*self.Leased_by).send_keys(data["LeasedBy"])

    def submit_update(self):
        """Submit the vehicle update form."""
        time.sleep(2)  # Wait for submit button to be ready
        self.driver.find_element(*self.SUBMIT_BUTTON).click()







