from selenium.webdriver.common.by import By
from selenium.webdriver.support.select import Select

from BasePage import BasePage
import time


class VehiclePage(BasePage):
    VEHICLE_TAB = (By.XPATH, "//a[normalize-space()='Vehicle']")
    FILTER_BUTTON = (By.XPATH, "//button[normalize-space()='Filter']")


    def __init__(self, driver):
        super().__init__(driver)

    def navigate_to_vehicle(self):
        self.click(self.VEHICLE_TAB)

    def click_on_search(self, fuelType):
        Filters=self.driver.find_element(By.ID, "fuelTypeDropdown")
        Select(Filters).select_by_visible_text(fuelType)


    def click_on_Filter(self):
        element = self.driver.find_element(*self.FILTER_BUTTON)
        time.sleep(1)  # Allow page to stabilize
        element.click()

