import time

from WebDriverSetup import WebDriverSetup
from HomePage import HomePage
from LoginPage import LoginPage
from Vehicle_Delete import VehiclePage

def test_vehicle_Delete():
    # Setup WebDriver
    setup = WebDriverSetup()
    driver = setup.get_driver()
    driver.get("https://abzmvcapp-chanad.azurewebsites.net/")

    # Validate Home Page
    home_page = HomePage(driver)
    assert driver.title == "Home Page - ABZVehicleInsuranceMVCAPP", "Home page title mismatch!"

    # Login
    home_page.click_login()
    login_page = LoginPage(driver)
    login_page.login("shyam123pr@gmail.com", "Sam@pr12")

    # Navigate to Vehicle Page and Delete Vehicle details
    vehicle_page = VehiclePage(driver)
    vehicle_page.navigate_to_vehicle()
    time.sleep(3)
    vehicle_page.click_on_action()
    vehicle_page.click_on_delete()
    time.sleep(3)
    vehicle_page.confirm_delete()

    # Close the browser
    driver.quit()

if __name__ == "__main__":
    test_vehicle_Delete()

