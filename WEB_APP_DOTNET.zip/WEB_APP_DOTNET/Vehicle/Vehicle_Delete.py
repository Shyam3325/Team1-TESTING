from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By
from BasePage import BasePage
import time


class VehiclePage(BasePage):
    VEHICLE_TAB = (By.XPATH, "//a[normalize-space()='Vehicle']")
    ACTION_BAR = (By.XPATH, "//tbody/tr[1]/td[16]/div[1]/button[1]")
    DELETE_BUTTON = (By.LINK_TEXT, "Delete")
    CONFIRM_DELETE = (By.CSS_SELECTOR,"input[value='Delete']")


    def __init__(self, driver):
        super().__init__(driver)

    def navigate_to_vehicle(self):
        self.click(self.VEHICLE_TAB)

    def click_on_action(self):
        action = ActionChains(self.driver)
        Dropdown=self.driver.find_element(*self.ACTION_BAR)
        action.move_to_element(Dropdown).click().perform()

    def click_on_delete(self):
        element = self.driver.find_element(*self.DELETE_BUTTON)
        time.sleep(1)  # Allow page to stabilize
        element.click()

    def confirm_delete(self):
        element = self.driver.find_element(*self.CONFIRM_DELETE)
        time.sleep(1)  # Allow page to stabilize
        element.click()




