from appium import webdriver
from selenium.webdriver.common.by import By
from appium.options.android import UiAutomator2Options
import time

desired_caps={
    "platformName": "android",
    "appium:automationName": "uiautomator2",
    "appium:deviceName": "Medium Phone API 35",
    "appium:ensureWebviewsHavePages": True,
    "appium:nativeWebScreenshot": True,
    "appium:newCommandTimeout": "8000",
    "appium:connectHardwareKeyboard": True,
    "appium:app": "C:\\Users\\shalu\\Downloads\\app-debug (10).apk"

}
options = UiAutomator2Options().load_capabilities(desired_caps)
driver = webdriver.Remote("http://localhost:4723",options=options)
time.sleep(5)

signup_button=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[3]/android.widget.Button')
signup_button.click()
time.sleep(3)

first_name=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[1]')
first_name.send_keys('JohnJacobs')
time.sleep(2)

last_name=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[2]')
last_name.send_keys('john')
time.sleep(2)

phone_numb_field=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[3]')
phone_numb_field.send_keys('8978674534')
time.sleep(2)

email_add=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[4]')
email_add.send_keys('john_jacobsgmail.com')

password_field=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[5]')
password_field.send_keys('johnjacobs@123456')
time.sleep(2)

cnf_password_field=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[6]')
cnf_password_field.send_keys('johnjacobs@123456')
time.sleep(2)

register=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.Button')
register.click()
time.sleep(5)
