from appium import webdriver
from selenium.webdriver.common.by import By
from appium.options.android import UiAutomator2Options
import time

desired_caps={
    "platformName": "android",
    "appium:automationName": "uiautomator2",
    "appium:deviceName": "Medium Phone API 35",
    "appium:ensureWebviewsHavePages": True,
    "appium:nativeWebScreenshot": True,
    "appium:newCommandTimeout": "8000",
    "appium:connectHardwareKeyboard": True,
    "appium:app": "C:\\Users\\shalu\\Downloads\\app-debug (3).apk"

}
options = UiAutomator2Options().load_capabilities(desired_caps)
driver = webdriver.Remote("http://localhost:4723",options=options)
time.sleep(5)

# Menu=driver.find_element(By.XPATH,"//android.widget.Button")
# Menu.click()
# time.sleep(5)
email=driver.find_element(By.XPATH,'//android.widget.EditText[@resource-id="com.singlepointsol.navigatioindrawerr:id/email_editText"]')
email.send_keys("")
time.sleep(3)

password=driver.find_element(By.XPATH,'//android.widget.EditText[@resource-id="com.singlepointsol.navigatioindrawerr:id/password_editText"]')
password.send_keys("")
time.sleep(3)

login=driver.find_element(By.XPATH,'//android.widget.Button[@resource-id="com.singlepointsol.navigatioindrawerr:id/login_button"]')
login.click()
time.sleep(5)
