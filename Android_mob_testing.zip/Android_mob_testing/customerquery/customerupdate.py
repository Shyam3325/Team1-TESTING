from appium import webdriver
from selenium.webdriver.common.by import By
from appium.options.android import UiAutomator2Options
import time

desired_caps={
    "platformName": "android",
    "appium:automationName": "uiautomator2",
    "appium:deviceName": "Medium Phone API 35",
    "appium:ensureWebviewsHavePages": True,
    "appium:nativeWebScreenshot": True,
    "appium:newCommandTimeout": "8000",
    "appium:connectHardwareKeyboard": True,
    "appium:app": "C:\\Users\\shalu\\Downloads\\app-debug (10).apk"

}
options = UiAutomator2Options().load_capabilities(desired_caps)
driver = webdriver.Remote("http://localhost:4723",options=options)
time.sleep(5)

# Menu=driver.find_element(By.XPATH,"//android.widget.Button")
# Menu.click()
# time.sleep(5)
email=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[1]')
email.send_keys("john_jacobs@gmail.com")
time.sleep(3)

password=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[2]')
password.send_keys("johnjacobs@123456")
time.sleep(3)

login=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[2]/android.widget.Button')
login.click()
time.sleep(15)

Menu=driver.find_element(By.XPATH,'//android.widget.ImageView[@content-desc="Menu Bar"]')
Menu.click()
time.sleep(5)

form=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.Button')
form.click()
time.sleep(3)

customer_query=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[10]/android.widget.Button')
customer_query.click()
time.sleep(3)

customer_queryid=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[1]').send_keys("abcde")
time.sleep(3)

customer_id=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[2]').send_keys("1235")
time.sleep(3)

description=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[1]').send_keys("customer query")
time.sleep(3)
reg_date=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[2]')
# reg_date.send_keys('04-01-2025')
reg_date.click()
reg_date.send_keys('04-01-2025')
time.sleep(3)
status=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[3]').send_keys("aabx")
time.sleep(3)
update=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[4]/android.widget.Button')
update.click()
time.sleep(2)
