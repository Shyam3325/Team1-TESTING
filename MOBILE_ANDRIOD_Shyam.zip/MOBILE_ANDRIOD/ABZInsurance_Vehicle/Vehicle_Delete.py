from appium import webdriver
from appium.options.android import UiAutomator2Options
from selenium.webdriver.common.by import By
import time


# Desired Capabilities
desired_caps = {
    "platformName": "android",
    "appium:automationName": "uiautomator2",
    "appium:deviceName": "vivo 1819",
    "appium:ensureWebviewsHavePages": True,
    "appium:nativeWebScreenshot": True,
    "appium:newCommandTimeout": 8000,
    "appium:connectHardwareKeyboard": True,
    "appium:appPackage": "com.singlepointsol.carinsurance",
    "appium:appActivity": "com.singlepointsol.carinsurance.MainActivity"
}

# Set up options
options = UiAutomator2Options().load_capabilities(desired_caps)

# Connect to Appium Server
driver = webdriver.Remote("http://localhost:4723", options=options)

time.sleep(5)
#Enter the login details and signin
Email = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[1]")
Email.send_keys("shyam123pr@gmail.com")
Password = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[2]")
Password.send_keys("Sam@pr12")
time.sleep(3)
Login = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[2]/android.widget.Button")
Login.click()
time.sleep(10)

#Click on menu
Menu = driver.find_element(By.XPATH, '//android.widget.ImageView[@content-desc="Menu Bar"]')
Menu.click()
time.sleep(10)
#click on forms
Forms = driver.find_element(By.XPATH, '//android.widget.TextView[@text="Forms"]')
Forms.click()
time.sleep(10)
#Click on Vehicle
Vehicle =driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]/android.widget.Button")
Vehicle.click()
time.sleep(10)

#Select Registered vehicle and delete
RegistrationNO = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[1]")
RegistrationNO.send_keys("TS12409845")
driver.hide_keyboard()
driver.find_element(
    "-android uiautomator",
    'new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text("DELETE"))'
)
#Click on delete to delete the vehicle details
Delete_btn = driver.find_element(By.XPATH, '//android.widget.TextView[@text="DELETE"]')
Delete_btn.click()