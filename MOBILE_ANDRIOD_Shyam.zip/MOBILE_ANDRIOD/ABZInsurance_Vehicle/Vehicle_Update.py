from appium import webdriver
from appium.options.android import UiAutomator2Options
from selenium.webdriver.common.by import By
import time


# Desired Capabilities
desired_caps = {
    "platformName": "android",
    "appium:automationName": "uiautomator2",
    "appium:deviceName": "vivo 1819",
    "appium:ensureWebviewsHavePages": True,
    "appium:nativeWebScreenshot": True,
    "appium:newCommandTimeout": 8000,
    "appium:connectHardwareKeyboard": True,
    "appium:appPackage": "com.singlepointsol.carinsurance",
    "appium:appActivity": "com.singlepointsol.carinsurance.MainActivity"
}

# Set up options
options = UiAutomator2Options().load_capabilities(desired_caps)

# Connect to Appium Server
driver = webdriver.Remote("http://localhost:4723", options=options)

time.sleep(5)
#Enter the login details and signin
Email = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[1]")
Email.send_keys("shyam123pr@gmail.com")
Password = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[2]")
Password.send_keys("Sam@pr12")
time.sleep(3)
Login = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[2]/android.widget.Button")
Login.click()
time.sleep(10)

#Click on menu
Menu = driver.find_element(By.XPATH, '//android.widget.ImageView[@content-desc="Menu Bar"]')
Menu.click()
time.sleep(10)
#click on forms
Forms = driver.find_element(By.XPATH, '//android.widget.TextView[@text="Forms"]')
Forms.click()
time.sleep(10)
#Click on Vehicle
Vehicle =driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]/android.widget.Button")
Vehicle.click()
time.sleep(10)
 #Update vehicle details
RegistrationNO = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[1]")
RegistrationNO.send_keys("TS12409844")
time.sleep(5)
driver.hide_keyboard()
driver.find_element(
    "-android uiautomator",
    'new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text("FETCH"))'
)
# Click Fetch to get Vehicle details
Fetch = driver.find_element(By.XPATH, '//android.widget.TextView[@text="FETCH"]')
Fetch.click()
time.sleep(3)
driver.find_element(
    "-android uiautomator",
    'new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text("Make"))'
)

Make = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[4]")
Make.click()
Make.send_keys("Rolls-Royce")
Model = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[5]")
Model.clear()
Model.send_keys("Phantom")
FuelType = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[6]")
FuelType.click()
time.sleep(5)
driver.find_element("-android uiautomator", 'new UiSelector().text("C")').click()
Variant = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[7]")
Variant.clear()
Variant.send_keys("Luxury")
driver.hide_keyboard()
EngineNo = driver.find_element(By.XPATH, '//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[8]')
EngineNo.clear()
EngineNo.send_keys("ENGSUP1234568789")
ChassisNo = driver.find_element(By.XPATH, '//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[9]')
ChassisNo.clear()
ChassisNo.send_keys("CHASUP123456789")
time.sleep(3)
driver.hide_keyboard()
driver.find_element(
    "-android uiautomator",
    'new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text("UPDATE"))'
)

#Click on update button to update vehicle details
Update_BTN = driver.find_element(By.XPATH, '//android.widget.TextView[@text="UPDATE"]')
Update_BTN.click()
