from appium import webdriver
from appium.options.android import UiAutomator2Options
from selenium.webdriver.common.by import By
import time


# Desired Capabilities
desired_caps = {
    "platformName": "android",
    "appium:automationName": "uiautomator2",
    "appium:deviceName": "vivo 1819",
    "appium:ensureWebviewsHavePages": True,
    "appium:nativeWebScreenshot": True,
    "appium:newCommandTimeout": 8000,
    "appium:connectHardwareKeyboard": True,
    "appium:appPackage": "com.singlepointsol.carinsurance",
    "appium:appActivity": "com.singlepointsol.carinsurance.MainActivity"
}

# Set up options
options = UiAutomator2Options().load_capabilities(desired_caps)

# Connect to Appium Server
driver = webdriver.Remote("http://localhost:4723", options=options)

time.sleep(5)
#Enter the login details and signin
Email = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[1]")
Email.send_keys("shyam123pr@gmail.com")
Password = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[2]")
Password.send_keys("Sam@pr12")
time.sleep(3)
Login = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[2]/android.widget.Button")
Login.click()
time.sleep(10)

#Click on menu
Menu = driver.find_element(By.XPATH, '//android.widget.ImageView[@content-desc="Menu Bar"]')
Menu.click()
time.sleep(10)
#click on forms
Forms = driver.find_element(By.XPATH, '//android.widget.TextView[@text="Forms"]')
Forms.click()
time.sleep(10)
#Click on Vehicle
Vehicle =driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]/android.widget.Button")
Vehicle.click()
time.sleep(10)
#Fill details in vehicle page
RegistrationNO = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[1]")
RegistrationNO.click()
time.sleep(5)
RegistrationNO.click()
time.sleep(3)
RegistrationNO.send_keys("AP03PR1111")
RegistrationAuth = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[2]")
RegistrationAuth.send_keys("Andhra pradesh")
Owner_ID = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[3]")
Owner_ID.click()
driver.find_element(
    "-android uiautomator",
    'new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text("CUS1234566"))'
)
time.sleep(3)
driver.find_element("-android uiautomator", 'new UiSelector().text("CUS1234566")').click()
time.sleep(3)
Make = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[4]")
Make.send_keys("Roll-Royce")
Model = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[5]")
Model.send_keys("Phantom")
FuelType = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[6]")
FuelType.click()
time.sleep(3)
driver.find_element("-android uiautomator", 'new UiSelector().text("P")').click()
driver.hide_keyboard()
Variant = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[7]")
Variant.send_keys("Luxury")
EngineNo = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[8]")
time.sleep(3)
EngineNo.send_keys("ENGSUP1234568789")
ChassisNo = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[9]")
ChassisNo.send_keys("CHASUP123456789")
driver.find_element(
    "-android uiautomator",
    'new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text("DELETE"))'
)
time.sleep(5)
EngCap = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[4]")
EngCap.send_keys("1998")
SeatCap = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[5]")
SeatCap.send_keys("4")
MfnYear = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[6]")
MfnYear.send_keys("2024")
Registration_Date=driver.find_element(By.XPATH,"//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[7]/android.view.View/android.widget.Button")
Registration_Date.click()
time.sleep(5)
driver.find_element(By.XPATH,"//android.view.View[@content-desc='10 June 2024']").click()
BodyType = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[8]")
BodyType.send_keys("Coupe")
LeasedBy = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[9]")
LeasedBy.send_keys("Shyam")
driver.hide_keyboard()
time.sleep(3)

#Click on Add to create Vehicle details
Add_BTN = driver.find_element(By.XPATH, '//android.widget.TextView[@text="ADD"]')
Add_BTN.click()


















