from selenium.webdriver.common.by import By
import time

class ProductDelete:
    def __init__(self, driver):
        self.driver = driver
        self.product_option = (By.XPATH, '//android.widget.TextView[@text="Product"]')
        self.product_id_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[1]")
        self.delete_button = (By.XPATH, '//android.widget.TextView[@text="DELETE"]')

    def select_product(self):
        """Navigate to Product option."""
        self.driver.find_element(*self.product_option).click()
        time.sleep(10)

    def fill_product_id(self, product_id):
        """Fill in the Product ID."""
        self.driver.find_element(*self.product_id_field).send_keys(product_id)
        self.driver.hide_keyboard()

    def click_delete(self):
        """Click the Delete button."""
        self.driver.find_element(*self.delete_button).click()
        time.sleep(5)
