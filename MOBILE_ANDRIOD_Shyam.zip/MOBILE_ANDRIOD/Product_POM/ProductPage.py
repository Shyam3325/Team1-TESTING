from selenium.webdriver.common.by import By

class ProductPage:
    def __init__(self, driver):
        self.driver = driver
        self.product_id_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[1]")
        self.product_name_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[2]")
        self.product_description_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[3]")
        self.product_uin_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[4]")
        self.insured_interest_dropdown = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[5]")
        self.policy_coverage_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[6]")
        self.add_button = (By.XPATH, '//android.widget.TextView[@text="ADD"]')

    def enter_product_id(self, product_id):
        self.driver.find_element(*self.product_id_field).send_keys(product_id)

    def enter_product_name(self, product_name):
        self.driver.find_element(*self.product_name_field).send_keys(product_name)

    def enter_product_description(self, product_description):
        self.driver.find_element(*self.product_description_field).send_keys(product_description)

    def enter_product_uin(self, product_uin):
        self.driver.find_element(*self.product_uin_field).send_keys(product_uin)

    def select_insured_interest(self, interest):
        self.driver.find_element(*self.insured_interest_dropdown).click()
        self.driver.find_element("-android uiautomator", f'new UiSelector().text("{interest}")').click()

    def enter_policy_coverage(self, policy_coverage):
        self.driver.find_element(*self.policy_coverage_field).send_keys(policy_coverage)

    def click_add_button(self):
        self.driver.find_element(*self.add_button).click()
