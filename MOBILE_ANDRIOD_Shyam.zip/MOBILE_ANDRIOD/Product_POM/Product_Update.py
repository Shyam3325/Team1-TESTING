from selenium.webdriver.common.by import By
import time

class ProductUpdate:
    def __init__(self, driver):
        self.driver = driver
        self.product_option = (By.XPATH, '//android.widget.TextView[@text="Product"]')
        self.product_id_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[1]")
        self.fetch_button = (By.XPATH, '//android.widget.TextView[@text="FETCH"]')
        self.product_name_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[2]")
        self.product_description_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[3]")
        self.policy_coverage_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[6]")
        self.update_button = (By.XPATH, '//android.widget.TextView[@text="UPDATE"]')

    def select_product(self):
        """Navigate to Product option."""
        self.driver.find_element(*self.product_option).click()
        time.sleep(10)

    def fetch_product(self, product_id):
        """Fetch Product Details."""
        self.driver.find_element(*self.product_id_field).send_keys(product_id)
        self.driver.hide_keyboard()
        time.sleep(3)
        self.driver.find_element(*self.fetch_button).click()
        time.sleep(5)

    def update_product_details(self, product_name, product_description, policy_coverage):
        """Update Product Details."""
        name_field = self.driver.find_element(*self.product_name_field)
        name_field.clear()
        name_field.send_keys(product_name)

        desc_field = self.driver.find_element(*self.product_description_field)
        desc_field.clear()
        desc_field.send_keys(product_description)

        coverage_field = self.driver.find_element(*self.policy_coverage_field)
        coverage_field.clear()
        coverage_field.send_keys(policy_coverage)

        self.driver.hide_keyboard()
        time.sleep(3)

    def click_update(self):
        """Click Update Button."""
        self.driver.find_element(*self.update_button).click()
