from selenium.webdriver.common.by import By
import time

class ProductFetch:
    def __init__(self, driver):
        self.driver = driver
        self.product_option = (By.XPATH, '//android.widget.TextView[@text="Product"]')
        self.product_id_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[1]")
        self.fetch_button = (By.XPATH, '//android.widget.TextView[@text="FETCH"]')

    def click_product(self):
        """Click the Product option."""
        self.driver.find_element(*self.product_option).click()
        time.sleep(10)

    def enter_product_id(self, product_id):
        """Enter the Product ID."""
        self.driver.find_element(*self.product_id_field).send_keys(product_id)

    def click_fetch(self):
        """Click the Fetch button."""
        self.driver.find_element(*self.fetch_button).click()
        time.sleep(5)
