from selenium.webdriver.common.by import By
from appium.webdriver.common.appiumby import AppiumBy

class DeletePage:
    def __init__(self, driver):
        self.driver = driver

    # Locators
    registration_no_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[1]")
    delete_button = (By.XPATH, '//android.widget.TextView[@text="DELETE"]')

    # Methods
    def enter_registration_number(self, registration_no):
        registration_field = self.driver.find_element(*self.registration_no_field)
        registration_field.send_keys(registration_no)
        self.driver.hide_keyboard()

    def scroll_to_delete(self):
        self.driver.find_element(
            AppiumBy.ANDROID_UIAUTOMATOR,
            'new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text("DELETE"))'
        )

    def click_delete_button(self):
        delete_btn = self.driver.find_element(*self.delete_button)
        delete_btn.click()
