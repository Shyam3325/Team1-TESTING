import unittest
from LoginPage import LoginPage
from MenuPage import MenuPage
from VehiclePage import VehiclePage
from appium import webdriver
from appium.options.android import UiAutomator2Options
import time

class TestVehicleCreation(unittest.TestCase):
    def test_vehicle_creation(self):
        # Desired Capabilities
        desired_caps = {
            "platformName": "android",
            "appium:automationName": "uiautomator2",
            "appium:deviceName": "vivo 1819",
            "appium:ensureWebviewsHavePages": True,
            "appium:nativeWebScreenshot": True,
            "appium:newCommandTimeout": 8000,
            "appium:connectHardwareKeyboard": True,
            "appium:appPackage": "com.singlepointsol.carinsurance",
            "appium:appActivity": "com.singlepointsol.carinsurance.MainActivity"
        }
        options = UiAutomator2Options().load_capabilities(desired_caps)
        driver = webdriver.Remote("http://localhost:4723", options=options)
        time.sleep(5)

        # Login
        login_page = LoginPage(driver)
        login_page.enter_email("shyam123pr@gmail.com")
        login_page.enter_password("Sam@pr12")
        time.sleep(3)
        login_page.click_login()
        time.sleep(10)

        # Navigate to Product Page
        menu_page = MenuPage(driver)
        menu_page.click_menu()
        time.sleep(5)
        menu_page.click_forms()
        time.sleep(5)
        menu_page.click_vehicle()
        time.sleep(10)

        # Vehicle Page
        vehicle_page = VehiclePage(driver)

        # Fill Vehicle Details
        vehicle_details = {
            "registration_no": "AP03PR1111",
            "registration_auth": "Andhra Pradesh",
            "owner_id": "CUS1234566",
            "make": "Roll-Royce",
            "model": "Phantom",
            "fuel_type": "P",
            "variant": "Luxury",
            "engine_no": "ENGSUP1234568789",
            "chassis_no": "CHASUP123456789",
            "engine_capacity": "1998",
            "seat_capacity": "4",
            "manufacturing_year": "2024",
            "registration_date": "01 January 2025",
            "body_type": "Coupe",
            "leased_by": "Shyam"
        }
        vehicle_page.fill_vehicle_details(vehicle_details)
        vehicle_page.click_add_button()
        time.sleep(5)

        print("Vehicle added successfully!")

        # Quit driver
        driver.quit()

if __name__ == "__main__":
    unittest.main()