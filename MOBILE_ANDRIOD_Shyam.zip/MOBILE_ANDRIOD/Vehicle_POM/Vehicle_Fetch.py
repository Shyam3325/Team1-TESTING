from selenium.webdriver.common.by import By


class VehicleFetch:
    def __init__(self, driver):
        self.driver = driver
        self.registration_no_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[1]")
        self.fetch_button = (By.XPATH, '//android.widget.TextView[@text="FETCH"]')

    def enter_registration_no(self, reg_no):
        """Enter the Registration Number."""
        self.driver.find_element(*self.registration_no_field).send_keys(reg_no)

    def click_fetch(self):
        """Click on the Fetch Button."""
        self.driver.find_element(*self.fetch_button).click()
