from selenium.webdriver.common.by import By

class MenuPage:
    def __init__(self, driver):
        self.driver = driver
        self.menu_button = (By.XPATH, '//android.widget.ImageView[@content-desc="Menu Bar"]')
        self.forms_button = (By.XPATH, '//android.widget.TextView[@text="Forms"]')
        self.vehicle_button = (By.XPATH, '//android.widget.TextView[@text="Vehicle"]')

    def click_menu(self):
        self.driver.find_element(*self.menu_button).click()

    def click_forms(self):
        self.driver.find_element(*self.forms_button).click()

    def click_vehicle(self):
        self.driver.find_element(*self.vehicle_button).click()
