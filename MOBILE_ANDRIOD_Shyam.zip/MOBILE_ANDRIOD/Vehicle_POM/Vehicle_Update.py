import time

from selenium.webdriver.common.by import By


class VehicleUpdate:
    def __init__(self, driver):
        self.driver = driver
        self.registration_no = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[1]")
        self.fetch_button = (By.XPATH, '//android.widget.TextView[@text="FETCH"]')
        self.make = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[4]")
        self.model = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[5]")
        self.fuel_type = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[6]")
        self.variant = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[7]")
        self.engine_no = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[8]")
        self.chassis_no = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[9]")
        self.update_button = (By.XPATH, '//android.widget.TextView[@text="UPDATE"]')

    def enter_registration_no(self, reg_no):
        """Enter the Registration Number."""
        self.driver.find_element(*self.registration_no).send_keys(reg_no)

    def click_fetch(self):
        """Click on the Fetch Button."""
        self.driver.find_element(*self.fetch_button).click()

    def enter_make(self, make):
        """Enter the Make."""
        self.driver.find_element(*self.make).clear()
        self.driver.find_element(*self.make).send_keys(make)

    def enter_model(self, model):
        """Enter the Model."""
        self.driver.find_element(*self.model).clear()
        self.driver.find_element(*self.model).send_keys(model)

    def select_fuel_type(self, fuel_type):
        """Select the Fuel Type."""
        self.driver.find_element(*self.fuel_type).click()
        time.sleep(5)
        self.driver.find_element("-android uiautomator", f'new UiSelector().text("{fuel_type}")').click()
        time.sleep(5)
        self.driver.hide_keyboard()

    def enter_variant(self, variant):
        """Enter the Variant."""
        self.driver.find_element(*self.variant).clear()
        self.driver.find_element(*self.variant).send_keys(variant)

    def enter_engine_no(self, engine_no):
        """Enter the Engine Number."""
        self.driver.find_element(*self.engine_no).clear()
        self.driver.find_element(*self.engine_no).send_keys(engine_no)

    def enter_chassis_no(self, chassis_no):
        """Enter the Chassis Number."""
        self.driver.find_element(*self.chassis_no).clear()
        self.driver.find_element(*self.chassis_no).send_keys(chassis_no)

    def click_update(self):
        """Click on the Update Button."""
        self.driver.find_element(*self.update_button).click()
