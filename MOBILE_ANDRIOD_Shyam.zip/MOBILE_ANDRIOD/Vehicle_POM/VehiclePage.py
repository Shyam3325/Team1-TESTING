from selenium.webdriver.common.by import By
import time

class VehiclePage:
    def __init__(self, driver):
        self.driver = driver

        # Locators
        self.vehicle_button = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[2]/android.widget.Button")
        self.registration_no_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[1]")
        self.registration_auth_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[2]")
        self.owner_id_dropdown = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[3]")
        self.make_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[4]")
        self.model_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[5]")
        self.fuel_type_dropdown = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[6]")
        self.variant_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[7]")
        self.engine_no_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[8]")
        self.chassis_no_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[9]")
        self.eng_cap_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[4]")
        self.seat_cap_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[5]")
        self.mfg_year_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[6]")
        self.registration_date_button = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[7]/android.view.View/android.widget.Button")
        self.body_type_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[8]")
        self.leased_by_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.widget.EditText[9]")
        self.add_button = (By.XPATH, '//android.widget.TextView[@text="ADD"]')

    def navigate_to_vehicle_page(self):
        """Navigate to the Vehicle page."""
        self.driver.find_element(*self.vehicle_button).click()
        time.sleep(10)

    def fill_vehicle_details(self, details):
        """Fill the vehicle details."""
        self.driver.find_element(*self.registration_no_field).send_keys(details["registration_no"])
        self.driver.find_element(*self.registration_auth_field).send_keys(details["registration_auth"])

        # Select Owner ID
        self.driver.find_element(*self.owner_id_dropdown).click()
        self.driver.find_element(
            "-android uiautomator",
            f'new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text("{details["owner_id"]}"))'
        )
        time.sleep(3)
        self.driver.find_element("-android uiautomator", f'new UiSelector().text("{details["owner_id"]}")').click()

        # Fill other fields
        self.driver.find_element(*self.make_field).send_keys(details["make"])
        self.driver.find_element(*self.model_field).send_keys(details["model"])
        self.driver.find_element(*self.fuel_type_dropdown).click()
        time.sleep(3)
        self.driver.find_element("-android uiautomator", f'new UiSelector().text("{details["fuel_type"]}")').click()
        time.sleep(5)
        self.driver.hide_keyboard()
        self.driver.find_element(*self.variant_field).send_keys(details["variant"])
        self.driver.find_element(*self.engine_no_field).send_keys(details["engine_no"])
        self.driver.find_element(*self.chassis_no_field).send_keys(details["chassis_no"])

        # Scroll to remaining fields
        self.driver.find_element(
            "-android uiautomator",
            'new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text("DELETE"))'
        )
        time.sleep(3)

        self.driver.find_element(*self.eng_cap_field).send_keys(details["engine_capacity"])
        self.driver.find_element(*self.seat_cap_field).send_keys(details["seat_capacity"])
        self.driver.find_element(*self.mfg_year_field).send_keys(details["manufacturing_year"])

        # Select Registration Date
        self.driver.find_element(*self.registration_date_button).click()
        time.sleep(3)
        self.driver.find_element(By.XPATH, f"//android.view.View[@content-desc='{details['registration_date']}']").click()
        self.driver.find_element(By.XPATH, '//android.widget.Button[@resource-id="android:id/button1"]').click()
        self.driver.find_element(*self.body_type_field).send_keys(details["body_type"])
        self.driver.find_element(*self.leased_by_field).send_keys(details["leased_by"])
        self.driver.hide_keyboard()
        time.sleep(3)

    def click_add_button(self):
        """Click the Add button to create vehicle details."""
        self.driver.find_element(*self.add_button).click()
