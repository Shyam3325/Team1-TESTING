import unittest
from LoginPage import LoginPage
from MenuPage import MenuPage
from Vehicle_Fetch import VehicleFetch
from appium import webdriver
from appium.options.android import UiAutomator2Options
import time

class TestVehicleUpdate(unittest.TestCase):
    def test_vehicle_Update(self):
        # Desired Capabilities
        desired_caps = {
            "platformName": "android",
            "appium:automationName": "uiautomator2",
            "appium:deviceName": "vivo 1819",
            "appium:ensureWebviewsHavePages": True,
            "appium:nativeWebScreenshot": True,
            "appium:newCommandTimeout": 8000,
            "appium:connectHardwareKeyboard": True,
            "appium:appPackage": "com.singlepointsol.carinsurance",
            "appium:appActivity": "com.singlepointsol.carinsurance.MainActivity"
        }
        options = UiAutomator2Options().load_capabilities(desired_caps)
        driver = webdriver.Remote("http://localhost:4723", options=options)
        time.sleep(5)

        # Login
        login_page = LoginPage(driver)
        login_page.enter_email("shyam123pr@gmail.com")
        login_page.enter_password("Sam@pr12")
        time.sleep(3)
        login_page.click_login()
        time.sleep(10)

        # Navigate to Product Page
        menu_page = MenuPage(driver)
        menu_page.click_menu()
        time.sleep(5)
        menu_page.click_forms()
        time.sleep(5)
        menu_page.click_vehicle()
        time.sleep(10)

        # Fetch Vehicle Details
        vehicle_Fetch = VehicleFetch(driver)
        vehicle_Fetch.enter_registration_no("TS12409844")
        time.sleep(5)
        driver.hide_keyboard()
        driver.find_element(
            "-android uiautomator",
            'new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text("FETCH"))'
        )
        vehicle_Fetch.click_fetch()
        time.sleep(5)

        print("Vehicle details fetched successfully!")

        # Quit driver
        driver.quit()

if __name__ == "__main__":
    unittest.main()