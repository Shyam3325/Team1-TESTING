from appium import webdriver
from appium.options.android import UiAutomator2Options
from selenium.webdriver.common.by import By
import time

# Desired Capabilities
desired_caps = {
    "platformName": "android",
    "appium:automationName": "uiautomator2",
    "appium:deviceName": "vivo 1819",
    "appium:ensureWebviewsHavePages": True,
    "appium:nativeWebScreenshot": True,
    "appium:newCommandTimeout": 8000,
    "appium:connectHardwareKeyboard": True,
    "appium:appPackage": "com.singlepointsol.carinsurance",
    "appium:appActivity": "com.singlepointsol.carinsurance.MainActivity"
}

# Set up options
options = UiAutomator2Options().load_capabilities(desired_caps)

# Connect to Appium Server
driver = webdriver.Remote("http://localhost:4723", options=options)

time.sleep(5)
#Enter the login details and signin
Email = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[1]")
Email.send_keys("shyam123pr@gmail.com")
Password = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[2]")
Password.send_keys("Sam@pr12")
time.sleep(3)
Login = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[2]/android.widget.Button")
Login.click()
time.sleep(10)

#Click on menu
Menu = driver.find_element(By.XPATH, '//android.widget.ImageView[@content-desc="Menu Bar"]')
Menu.click()
time.sleep(10)
#click on forms
Forms = driver.find_element(By.XPATH, '//android.widget.TextView[@text="Forms"]')
Forms.click()
time.sleep(10)
#Click on products
Product = driver.find_element(By.XPATH, '//android.widget.TextView[@text="Product"]')
Product.click()
time.sleep(10)
#Fill product details
ProductID = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[1]")
ProductID.send_keys("PROD123450")
driver.hide_keyboard()
time.sleep(3)
#Click on fetch Button
Fetch = driver.find_element(By.XPATH, '//android.widget.TextView[@text="FETCH"]')
Fetch.click()
time.sleep(5)
#Update required details
ProductName = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[2]")
ProductName.clear()
ProductName.send_keys("Thirdparty")
ProductDes = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[3]")
ProductDes.clear()
ProductDes.send_keys("Covers legal liability for third-party damage or injury")
PolicyCoverage = driver.find_element(By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[6]")
PolicyCoverage.clear()
PolicyCoverage.send_keys("3 years")
driver.hide_keyboard()

#Click on Update button
Update = driver.find_element(By.XPATH, '//android.widget.TextView[@text="UPDATE"]')
Update.click()
