import unittest
from LoginPage import LoginPage
from MenuPage import MenuPage
from Addon_Create import AddonPage
from appium import webdriver
from appium.options.android import UiAutomator2Options
import time

class TestProductCreation(unittest.TestCase):
    def test_product_creation(self):
        # Desired Capabilities
        desired_caps = {
            "platformName": "android",
            "appium:automationName": "uiautomator2",
            "appium:deviceName": "vivo 1819",
            "appium:ensureWebviewsHavePages": True,
            "appium:nativeWebScreenshot": True,
            "appium:newCommandTimeout": 8000,
            "appium:connectHardwareKeyboard": True,
            "appium:appPackage": "com.singlepointsol.carinsurance",
            "appium:appActivity": "com.singlepointsol.carinsurance.MainActivity"
        }
        options = UiAutomator2Options().load_capabilities(desired_caps)
        driver = webdriver.Remote("http://localhost:4723", options=options)
        time.sleep(5)

        # Login
        login_page = LoginPage(driver)
        login_page.enter_email("shyam123pr@gmail.com")
        login_page.enter_password("Sam@pr12")
        time.sleep(3)
        login_page.click_login()
        time.sleep(10)

        # Navigate to Product Page
        menu_page = MenuPage(driver)
        menu_page.click_menu()
        time.sleep(5)
        menu_page.click_forms()
        time.sleep(5)
        menu_page.click_ProductAddon()
        time.sleep(10)

        addon_page = AddonPage(driver)

        # Fill Addon details
        addon_page.enter_addon_id("ADD1234560")
        time.sleep(2)
        addon_page.select_product_id("PROD123458")
        time.sleep(2)
        addon_page.enter_addon_title("Roadside Assistance")
        addon_page.enter_addon_description(
            "Offers services like towing, battery jump-starts, and emergency fuel delivery.")
        time.sleep(2)

        # Click on Add
        addon_page.click_add()
        time.sleep(5)

        # Validate or add assertions if required
        print("Addon details submitted successfully!")

        # Quit driver
        driver.quit()

if __name__ == "__main__":
    unittest.main()
