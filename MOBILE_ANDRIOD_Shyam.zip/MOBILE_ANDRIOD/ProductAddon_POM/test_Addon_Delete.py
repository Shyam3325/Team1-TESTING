import unittest
from LoginPage import LoginPage
from MenuPage import MenuPage
from Addon_Delete import DeletePage
from appium import webdriver
from appium.options.android import UiAutomator2Options
import time

class TestProductDelete(unittest.TestCase):
    def test_product_delete(self):
        # Desired Capabilities
        desired_caps = {
            "platformName": "android",
            "appium:automationName": "uiautomator2",
            "appium:deviceName": "vivo 1819",
            "appium:ensureWebviewsHavePages": True,
            "appium:nativeWebScreenshot": True,
            "appium:newCommandTimeout": 8000,
            "appium:connectHardwareKeyboard": True,
            "appium:appPackage": "com.singlepointsol.carinsurance",
            "appium:appActivity": "com.singlepointsol.carinsurance.MainActivity"
        }
        options = UiAutomator2Options().load_capabilities(desired_caps)
        driver = webdriver.Remote("http://localhost:4723", options=options)
        time.sleep(5)

        # Login
        login_page = LoginPage(driver)
        login_page.enter_email("shyam123pr@gmail.com")
        login_page.enter_password("Sam@pr12")
        time.sleep(3)
        login_page.click_login()
        time.sleep(10)

        # Navigate to Product Page
        menu_page = MenuPage(driver)
        menu_page.click_menu()
        time.sleep(5)
        menu_page.click_forms()
        time.sleep(5)
        menu_page.click_ProductAddon()
        time.sleep(10)

        delete_page = DeletePage(driver)

        # Enter Addon ID
        delete_page.enter_addon_id("ADD1234560")
        time.sleep(2)

        # Select Product ID
        delete_page.select_product_id("PROD123458")
        time.sleep(2)

        # Click Delete button
        delete_page.click_delete()
        time.sleep(5)

        # Add assertions or validations as needed
        print("Deleted Addon details successfully!")

        # Quit driver
        driver.quit()

if __name__ == "__main__":
    unittest.main()