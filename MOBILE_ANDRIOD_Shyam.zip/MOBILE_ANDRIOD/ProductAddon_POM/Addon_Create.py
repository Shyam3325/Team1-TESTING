from selenium.webdriver.common.by import By
from appium.webdriver.common.appiumby import AppiumBy

class AddonPage:
    def __init__(self, driver):
        self.driver = driver

    # Locators
    addon_id_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[1]")
    product_id_dropdown = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[2]")
    addon_title_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[3]")
    addon_description_field = (By.XPATH, "//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[4]")
    add_button = (By.XPATH, '//android.widget.TextView[@text="ADD"]')

    # Methods
    def enter_addon_id(self, addon_id):
        addon_id_field = self.driver.find_element(*self.addon_id_field)
        addon_id_field.send_keys(addon_id)

    def select_product_id(self, product_id):
        product_dropdown = self.driver.find_element(*self.product_id_dropdown)
        product_dropdown.click()
        self.driver.find_element(
            AppiumBy.ANDROID_UIAUTOMATOR,
            f'new UiScrollable(new UiSelector().scrollable(true)).scrollIntoView(new UiSelector().text("{product_id}"))'
        )
        self.driver.find_element(AppiumBy.ANDROID_UIAUTOMATOR, f'new UiSelector().text("{product_id}")').click()

    def enter_addon_title(self, title):
        addon_title_field = self.driver.find_element(*self.addon_title_field)
        addon_title_field.send_keys(title)

    def enter_addon_description(self, description):
        addon_description_field = self.driver.find_element(*self.addon_description_field)
        addon_description_field.send_keys(description)
        self.driver.hide_keyboard()

    def click_add(self):
        add_btn = self.driver.find_element(*self.add_button)
        add_btn.click()
