import unittest
from LoginPage import LoginPage
from MenuPage import MenuPage
from Addon_Update import UpdatePage
from appium import webdriver
from appium.options.android import UiAutomator2Options
import time

class TestProductUpdate(unittest.TestCase):
    def test_product_update(self):
        # Desired Capabilities
        desired_caps = {
            "platformName": "android",
            "appium:automationName": "uiautomator2",
            "appium:deviceName": "vivo 1819",
            "appium:ensureWebviewsHavePages": True,
            "appium:nativeWebScreenshot": True,
            "appium:newCommandTimeout": 8000,
            "appium:connectHardwareKeyboard": True,
            "appium:appPackage": "com.singlepointsol.carinsurance",
            "appium:appActivity": "com.singlepointsol.carinsurance.MainActivity"
        }
        options = UiAutomator2Options().load_capabilities(desired_caps)
        driver = webdriver.Remote("http://localhost:4723", options=options)
        time.sleep(5)

        # Login
        login_page = LoginPage(driver)
        login_page.enter_email("shyam123pr@gmail.com")
        login_page.enter_password("Sam@pr12")
        time.sleep(3)
        login_page.click_login()
        time.sleep(10)

        # Navigate to Product Page
        menu_page = MenuPage(driver)
        menu_page.click_menu()
        time.sleep(5)
        menu_page.click_forms()
        time.sleep(5)
        menu_page.click_ProductAddon()
        time.sleep(10)

        update_page = UpdatePage(driver)
        # Enter Addon ID and select Product ID
        update_page.enter_addon_id("ADD1234560")
        time.sleep(2)
        update_page.select_product_id("PROD123458")
        time.sleep(2)

        # Fetch the Addon details
        update_page.click_fetch()
        time.sleep(5)

        # Update Addon Title and Description
        update_page.update_addon_title("Return to Invoice")
        update_page.update_addon_description(
            "Reimburses the insured with the full invoice value of the vehicle in case of total loss or theft.")
        time.sleep(3)

        # Click on Update
        update_page.click_update()
        time.sleep(5)

        # Validation or assertion can be added here
        print("Addon details updated successfully!")

        # Quit driver
        driver.quit()

if __name__ == "__main__":
    unittest.main()