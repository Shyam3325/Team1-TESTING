from appium import webdriver
from selenium.webdriver.common.by import By
from appium.options.android import UiAutomator2Options
import time

desired_caps={
    "platformName": "android",
    "appium:automationName": "uiautomator2",
    "appium:deviceName": "Medium Phone API 35",
    "appium:ensureWebviewsHavePages": True,
    "appium:nativeWebScreenshot": True,
    "appium:newCommandTimeout": "8000",
    "appium:connectHardwareKeyboard": True,
    "appium:app": "C:\\Users\\shalu\\Downloads\\app-debug (3).apk"

}
options = UiAutomator2Options().load_capabilities(desired_caps)
driver = webdriver.Remote("http://localhost:4723",options=options)
time.sleep(5)

register_button=driver.find_element(By.XPATH,'//android.widget.Button[@resource-id="com.singlepointsol.navigatioindrawerr:id/register_textButton"]')
register_button.click()
time.sleep(3)

name_field=driver.find_element(By.XPATH,'//android.widget.EditText[@resource-id="com.singlepointsol.navigatioindrawerr:id/name_et"]')
name_field.send_keys('J124 Jacobs')
time.sleep(2)

email_field=driver.find_element(By.XPATH,'//android.widget.EditText[@resource-id="com.singlepointsol.navigatioindrawerr:id/registeremail_editText"]')
email_field.send_keys('john_jacobs@gmail.com')
time.sleep(2)

phone_numb_field=driver.find_element(By.XPATH,'//android.widget.EditText[@resource-id="com.singlepointsol.navigatioindrawerr:id/phone_et"]')
phone_numb_field.send_keys('8974534')
time.sleep(2)

password_field=driver.find_element(By.XPATH,'//android.widget.EditText[@resource-id="com.singlepointsol.navigatioindrawerr:id/password_editText"]')
password_field.send_keys('johnjacobs@123456')
time.sleep(2)

cnf_password_field=driver.find_element(By.XPATH,'//android.widget.EditText[@resource-id="com.singlepointsol.navigatioindrawerr:id/confirmpassword_editText"]')
cnf_password_field.send_keys('johnjacobs@123456')
time.sleep(2)

register=driver.find_element(By.XPATH,'//android.widget.Button[@resource-id="com.singlepointsol.navigatioindrawerr:id/register"]')
register.click()
time.sleep(5)