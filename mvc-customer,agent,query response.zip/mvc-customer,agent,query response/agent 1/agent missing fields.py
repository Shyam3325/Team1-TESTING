from selenium import webdriver
from selenium.webdriver.common.by import By
import time
driver = webdriver.Chrome()
driver.get("https://abzmvcapp-chanad.azurewebsites.net/")
driver.maximize_window()
driver.implicitly_wait(5)
driver.find_element(By.XPATH,"/html/body/header/nav/div/div/ul[2]/li[2]/a").click()
email=driver.find_element(By.ID,"Input_Email").send_keys("konnegarishivani09@gmail.com")
password=driver.find_element(By.ID,"Input_Password").send_keys("Shiv@ni032002")
login_button=driver.find_element(By.ID,"login-submit").click()
driver.find_element(By.XPATH,"/html/body/header/nav/div/div/ul[1]/li[3]/a").click()
driver.find_element(By.XPATH,"/html/body/div/main/p/a").click()
agent_id=driver.find_element(By.ID,"AgentID").send_keys("")
agent_name=driver.find_element(By.ID,"AgentName").send_keys("")
agent_phone=driver.find_element(By.ID,"AgentPhone").send_keys("")
agent_email=driver.find_element(By.ID,"AgentEmail").send_keys("")
licensce_code=driver.find_element(By.ID,"LicenseCode").send_keys("")
create_button=driver.find_element(By.XPATH,"/html/body/div/main/div[1]/div/form/div[6]/input").click()
Agent_iderror=driver.find_element(By.XPATH,"//span[@id='AgentID-error']").text
print("The AgentID field is required.")
Agent_nameerr=driver.find_element(By.XPATH,"//*[@id='AgentName-error']").text
print("The AgentName field is required.")
Agent_phoneerr=driver.find_element(By.XPATH,"//*[@id='AgentPhone-error']").text
print("The AgentPhone field is required.")
Agent_emailerr=driver.find_element(By.XPATH,"//*[@id='AgentEmail-error']").text
print("The AgentEmail field is required.")
LC_error=driver.find_element(By.XPATH,"//*[@id='LicenseCode-error']").text
print("The LicenseCode field is required.")