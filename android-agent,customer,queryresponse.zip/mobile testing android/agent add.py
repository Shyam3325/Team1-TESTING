from appium import webdriver
from selenium.webdriver.common.by import By
from appium.options.android import UiAutomator2Options
import time

desired_caps={
    "platformName": "android",
    "appium:automationName": "uiautomator2",
    "appium:deviceName": "Medium_Phone_API_35_2:5554",
    "appium:ensureWebviewsHavePages": True,
    "appium:nativeWebScreenshot": True,
    "appium:newCommandTimeout": "8000",
    "appium:connectHardwareKeyboard": True,
    "appium:appPackage": "com.singlepointsol.carinsurance",
    "appium:appActivity": "com.singlepointsol.carinsurance.MainActivity"
}
options = UiAutomator2Options().load_capabilities(desired_caps)
driver = webdriver.Remote("http://localhost:4723",options=options)
time.sleep(5)

email=driver.find_element(By.XPATH,"//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[1]").send_keys("konnegarishivani09@gmail.com")
password=driver.find_element(By.XPATH,"//androidx.compose.ui.platform.ComposeView/android.view.View/android.widget.EditText[2]").send_keys("Shivanireddy032002")
login=driver.find_element(By.XPATH,"//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[2]/android.widget.Button").click()
time.sleep(10)
Menu=driver.find_element(By.XPATH,"//android.widget.ImageView[@content-desc='Menu Bar']").click()
time.sleep(5)
forms=driver.find_element(By.XPATH,'//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.widget.Button')
forms.click()
time.sleep(3)
agent_button=driver.find_element(By.XPATH,"//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View/android.view.View[5]/android.widget.Button").click()
time.sleep(2)
agent_id=driver.find_element(By.XPATH,"//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[1]")
agent_id.click()
time.sleep(5)
agent_id.click()
time.sleep(5)
agent_id.send_keys("A009976541")
time.sleep(10)
agent_name=driver.find_element(By.XPATH,"//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[2]").send_keys("Akshay")
time.sleep(5)
agent_phone=driver.find_element(By.XPATH,"//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[3]").send_keys("987612340")
time.sleep(5)
agent_email=driver.find_element(By.XPATH,"//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[4]").send_keys("Akshay@gmail.com")
time.sleep(5)
licensce_code=driver.find_element(By.XPATH,"//androidx.compose.ui.platform.ComposeView/android.view.View/android.view.View[1]/android.widget.EditText[5]").send_keys("000098")
time.sleep(5)
add_button=driver.find_element(By.XPATH,"//android.widget.TextView[@text='ADD']").click()
time.sleep(5)